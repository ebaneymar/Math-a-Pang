const {app, BrowserWindow, ipcMain, shell} = require("electron");
const path = require("path");
const fs = require("fs");
const https = require("https");
const http = require("http");
const crypto = require("crypto");
const os = require("os");
const {spawn} = require("child_process");

const APP_VERSION = "1.1.0";
const appDir = () => app.isPackaged ? path.dirname(process.execPath) : __dirname;
const resourcesAppDir = () => app.isPackaged ? path.join(process.resourcesPath, "app") : __dirname;
const dataDir = () => path.join(appDir(), "Data");
const saveFile = () => path.join(dataDir(), "MATH-a-PANG_Data.json");
const updaterConfigFile = () => path.join(appDir(), "UpdaterConfig.json");

let mainWindow = null;
let lastCheckedManifest = null;

function ensureDataFolder(){
  fs.mkdirSync(dataDir(), {recursive:true});
}

function readState(){
  ensureDataFolder();
  try{
    const raw=fs.readFileSync(saveFile(),"utf8");
    const data=JSON.parse(raw);
    return data && typeof data==="object" ? data : {localStorage:{}};
  }catch(e){
    return {version:1,localStorage:{}};
  }
}

function writeState(data){
  ensureDataFolder();
  const target=saveFile();
  const temp=target+".tmp";
  const payload={
    version:1,
    savedAt:new Date().toISOString(),
    localStorage:(data && data.localStorage && typeof data.localStorage==="object")
      ? data.localStorage
      : {}
  };
  fs.writeFileSync(temp,JSON.stringify(payload,null,2),"utf8");
  fs.renameSync(temp,target);
}

function defaultUpdaterConfig(){
  return {
    manifestUrl:"",
    autoCheck:true,
    channel:"stable"
  };
}

function readUpdaterConfig(){
  try{
    const parsed=JSON.parse(fs.readFileSync(updaterConfigFile(),"utf8"));
    return {
      ...defaultUpdaterConfig(),
      ...(parsed && typeof parsed==="object" ? parsed : {})
    };
  }catch(e){
    return defaultUpdaterConfig();
  }
}

function writeUpdaterConfig(input){
  const cfg=defaultUpdaterConfig();
  if(input && typeof input==="object"){
    cfg.manifestUrl=String(input.manifestUrl||"").trim();
    cfg.autoCheck=input.autoCheck!==false;
    cfg.channel=String(input.channel||"stable").trim()||"stable";
  }
  fs.writeFileSync(updaterConfigFile(),JSON.stringify(cfg,null,2),"utf8");
  return cfg;
}

function isAllowedUpdateUrl(raw){
  try{
    const u=new URL(String(raw||"").trim());
    if(u.protocol==="https:")return true;
    if(u.protocol==="http:" && ["localhost","127.0.0.1","::1"].includes(u.hostname))return true;
    return false;
  }catch(e){
    return false;
  }
}

function requestBuffer(url, redirects=0){
  return new Promise((resolve,reject)=>{
    if(redirects>8)return reject(new Error("Too many redirects."));
    if(!isAllowedUpdateUrl(url))return reject(new Error("Update URL must use HTTPS."));

    const parsed=new URL(url);
    const client=parsed.protocol==="https:" ? https : http;

    const req=client.get(parsed,{
      headers:{
        "User-Agent":`MATH-a-PANG/${APP_VERSION}`,
        "Accept":"application/json, application/octet-stream, */*"
      }
    },res=>{
      const status=Number(res.statusCode||0);
      if([301,302,303,307,308].includes(status) && res.headers.location){
        const next=new URL(res.headers.location,parsed).toString();
        res.resume();
        requestBuffer(next,redirects+1).then(resolve,reject);
        return;
      }
      if(status<200 || status>=300){
        res.resume();
        reject(new Error(`Update server returned HTTP ${status}.`));
        return;
      }
      const chunks=[];
      res.on("data",chunk=>chunks.push(chunk));
      res.on("end",()=>resolve(Buffer.concat(chunks)));
    });
    req.setTimeout(30000,()=>req.destroy(new Error("Update request timed out.")));
    req.on("error",reject);
  });
}

function downloadToFile(url,target,onProgress,redirects=0){
  return new Promise((resolve,reject)=>{
    if(redirects>8)return reject(new Error("Too many redirects."));
    if(!isAllowedUpdateUrl(url))return reject(new Error("Download URL must use HTTPS."));

    const parsed=new URL(url);
    const client=parsed.protocol==="https:" ? https : http;
    const req=client.get(parsed,{
      headers:{
        "User-Agent":`MATH-a-PANG/${APP_VERSION}`,
        "Accept":"application/zip, application/octet-stream, */*"
      }
    },res=>{
      const status=Number(res.statusCode||0);
      if([301,302,303,307,308].includes(status) && res.headers.location){
        const next=new URL(res.headers.location,parsed).toString();
        res.resume();
        downloadToFile(next,target,onProgress,redirects+1).then(resolve,reject);
        return;
      }
      if(status<200 || status>=300){
        res.resume();
        reject(new Error(`Update download returned HTTP ${status}.`));
        return;
      }

      const total=Math.max(0,Number(res.headers["content-length"]||0));
      let received=0;
      const file=fs.createWriteStream(target);

      res.on("data",chunk=>{
        received+=chunk.length;
        if(typeof onProgress==="function"){
          onProgress({
            received,
            total,
            percent:total ? Math.min(100,Math.round(received*100/total)) : null
          });
        }
      });

      res.pipe(file);
      file.on("finish",()=>{
        file.close(()=>resolve({received,total}));
      });
      file.on("error",err=>{
        try{fs.unlinkSync(target)}catch(e){}
        reject(err);
      });
    });
    req.setTimeout(60000,()=>req.destroy(new Error("Update download timed out.")));
    req.on("error",reject);
  });
}

function semverParts(v){
  return String(v||"0")
    .replace(/^v/i,"")
    .split(/[.-]/)
    .slice(0,3)
    .map(x=>Math.max(0,parseInt(x,10)||0));
}

function compareVersions(a,b){
  const aa=semverParts(a), bb=semverParts(b);
  for(let i=0;i<3;i++){
    const av=aa[i]||0, bv=bb[i]||0;
    if(av>bv)return 1;
    if(av<bv)return -1;
  }
  return 0;
}

function validateManifest(m){
  if(!m || typeof m!=="object")throw new Error("Invalid update manifest.");
  if(String(m.app||"").toLowerCase()!=="math-a-pang".toLowerCase()){
    throw new Error("This update is not for MATH-a-PANG.");
  }
  if(!String(m.version||"").trim())throw new Error("Manifest has no version.");
  if(!isAllowedUpdateUrl(m.downloadUrl))throw new Error("Manifest download URL must use HTTPS.");
  if(!/^[a-f0-9]{64}$/i.test(String(m.sha256||""))){
    throw new Error("Manifest SHA-256 is missing or invalid.");
  }
  const packageType=String(m.packageType||"app").toLowerCase();
  if(!["app","full"].includes(packageType)){
    throw new Error("Unsupported update package type.");
  }
  return {
    app:"MATH-a-PANG",
    version:String(m.version).trim(),
    published:String(m.published||""),
    downloadUrl:String(m.downloadUrl).trim(),
    sha256:String(m.sha256).toLowerCase(),
    packageType,
    notes:Array.isArray(m.notes)?m.notes.map(x=>String(x)).slice(0,20):[],
    size:Number(m.size||0)||0
  };
}

async function checkForUpdate(){
  const cfg=readUpdaterConfig();
  if(!cfg.manifestUrl){
    return {ok:false,status:"not-configured",currentVersion:APP_VERSION};
  }
  if(!isAllowedUpdateUrl(cfg.manifestUrl)){
    return {ok:false,status:"bad-url",currentVersion:APP_VERSION,error:"Update source must use HTTPS."};
  }

  try{
    const buf=await requestBuffer(cfg.manifestUrl);
    let parsed;
    try{parsed=JSON.parse(buf.toString("utf8"))}
    catch(e){throw new Error("Update manifest is not valid JSON.");}

    const manifest=validateManifest(parsed);
    lastCheckedManifest=manifest;
    const newer=compareVersions(manifest.version,APP_VERSION)>0;

    return {
      ok:true,
      status:newer?"available":"up-to-date",
      currentVersion:APP_VERSION,
      manifest:newer?manifest:null,
      latestVersion:manifest.version
    };
  }catch(error){
    return {
      ok:false,
      status:"error",
      currentVersion:APP_VERSION,
      error:error && error.message ? error.message : String(error)
    };
  }
}

function sha256File(file){
  return new Promise((resolve,reject)=>{
    const hash=crypto.createHash("sha256");
    const stream=fs.createReadStream(file);
    stream.on("data",d=>hash.update(d));
    stream.on("end",()=>resolve(hash.digest("hex")));
    stream.on("error",reject);
  });
}

function updaterPowerShell(){
  return String.raw`param(
  [int]$PidToWait,
  [string]$ZipPath,
  [string]$ResourcesAppDir,
  [string]$ExePath,
  [string]$PackageType,
  [string]$InstallRoot
)

$ErrorActionPreference = "Stop"

while (Get-Process -Id $PidToWait -ErrorAction SilentlyContinue) {
  Start-Sleep -Milliseconds 350
}

$Work = Join-Path $env:TEMP ("MATH-a-PANG-update-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $Work | Out-Null
Expand-Archive -LiteralPath $ZipPath -DestinationPath $Work -Force

try {
  if ($PackageType -eq "app") {
    $Source = Join-Path $Work "app"
    if (-not (Test-Path $Source)) { $Source = $Work }

    $Backup = $ResourcesAppDir + ".backup"
    if (Test-Path $Backup) { Remove-Item $Backup -Recurse -Force }

    if (Test-Path $ResourcesAppDir) {
      Move-Item $ResourcesAppDir $Backup -Force
    }

    try {
      New-Item -ItemType Directory -Force -Path $ResourcesAppDir | Out-Null
      Copy-Item (Join-Path $Source "*") $ResourcesAppDir -Recurse -Force
      if (Test-Path $Backup) { Remove-Item $Backup -Recurse -Force }
    } catch {
      if (Test-Path $ResourcesAppDir) { Remove-Item $ResourcesAppDir -Recurse -Force }
      if (Test-Path $Backup) { Move-Item $Backup $ResourcesAppDir -Force }
      throw
    }
  }
  elseif ($PackageType -eq "full") {
    $Source = Join-Path $Work "full"
    if (-not (Test-Path $Source)) { $Source = $Work }

    $DataPath = Join-Path $InstallRoot "Data"
    $DataBackup = Join-Path $Work "__DataBackup"
    if (Test-Path $DataPath) {
      Copy-Item $DataPath $DataBackup -Recurse -Force
    }

    Copy-Item (Join-Path $Source "*") $InstallRoot -Recurse -Force

    if (Test-Path $DataBackup) {
      if (Test-Path $DataPath) { Remove-Item $DataPath -Recurse -Force }
      Copy-Item $DataBackup $DataPath -Recurse -Force
    }
  }

  Start-Process -FilePath $ExePath -WorkingDirectory $InstallRoot
}
finally {
  Start-Sleep -Milliseconds 700
  try { Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue } catch {}
  try { Remove-Item $Work -Recurse -Force -ErrorAction SilentlyContinue } catch {}
}`;
}

async function installLastUpdate(){
  const checked=await checkForUpdate();
  if(!checked.ok || checked.status!=="available" || !checked.manifest){
    return checked;
  }
  const manifest=checked.manifest;

  const tempDir=path.join(os.tmpdir(),"MATH-a-PANG-Updater");
  fs.mkdirSync(tempDir,{recursive:true});
  const zipPath=path.join(tempDir,`MATH-a-PANG-${manifest.version}-${Date.now()}.zip`);

  try{
    await downloadToFile(manifest.downloadUrl,zipPath,progress=>{
      if(mainWindow && !mainWindow.isDestroyed()){
        mainWindow.webContents.send("mathapang:update-progress",{
          stage:"downloading",
          ...progress,
          version:manifest.version
        });
      }
    });

    if(mainWindow && !mainWindow.isDestroyed()){
      mainWindow.webContents.send("mathapang:update-progress",{
        stage:"verifying",
        version:manifest.version
      });
    }

    const actualHash=(await sha256File(zipPath)).toLowerCase();
    if(actualHash!==manifest.sha256){
      try{fs.unlinkSync(zipPath)}catch(e){}
      throw new Error("Update verification failed. SHA-256 does not match.");
    }

    const scriptPath=path.join(tempDir,`apply-update-${Date.now()}.ps1`);
    fs.writeFileSync(scriptPath,updaterPowerShell(),"utf8");

    if(mainWindow && !mainWindow.isDestroyed()){
      mainWindow.webContents.send("mathapang:update-progress",{
        stage:"installing",
        version:manifest.version
      });
    }

    const args=[
      "-NoLogo",
      "-NoProfile",
      "-ExecutionPolicy","Bypass",
      "-File",scriptPath,
      "-PidToWait",String(process.pid),
      "-ZipPath",zipPath,
      "-ResourcesAppDir",resourcesAppDir(),
      "-ExePath",process.execPath,
      "-PackageType",manifest.packageType,
      "-InstallRoot",appDir()
    ];

    const child=spawn("powershell.exe",args,{
      detached:true,
      stdio:"ignore",
      windowsHide:true
    });
    child.unref();

    setTimeout(()=>app.quit(),350);

    return {ok:true,status:"installing",version:manifest.version};
  }catch(error){
    try{if(fs.existsSync(zipPath))fs.unlinkSync(zipPath)}catch(e){}
    return {
      ok:false,
      status:"error",
      error:error && error.message ? error.message : String(error)
    };
  }
}

ipcMain.on("mathapang:load-state-sync",(event)=>{
  event.returnValue=readState();
});

ipcMain.on("mathapang:save-state-sync",(event,data)=>{
  try{writeState(data);event.returnValue=true;}
  catch(e){console.error(e);event.returnValue=false;}
});

ipcMain.handle("mathapang:save-state",async(_event,data)=>{
  writeState(data);
  return {ok:true,path:saveFile()};
});

ipcMain.handle("mathapang:open-data-folder",async()=>{
  ensureDataFolder();
  await shell.openPath(dataDir());
  return {ok:true,path:dataDir()};
});

ipcMain.handle("mathapang:updater-info",async()=>{
  const cfg=readUpdaterConfig();
  return {
    version:APP_VERSION,
    config:cfg,
    configured:Boolean(cfg.manifestUrl),
    configPath:updaterConfigFile()
  };
});

ipcMain.handle("mathapang:updater-save-config",async(_event,input)=>{
  const url=String(input && input.manifestUrl || "").trim();
  if(url && !isAllowedUpdateUrl(url)){
    return {ok:false,error:"Update source must be an HTTPS URL."};
  }
  const cfg=writeUpdaterConfig({
    manifestUrl:url,
    autoCheck:input && input.autoCheck!==false,
    channel:"stable"
  });
  return {ok:true,config:cfg};
});

ipcMain.handle("mathapang:updater-check",async()=>checkForUpdate());
ipcMain.handle("mathapang:updater-install",async()=>installLastUpdate());

ipcMain.on("mathapang:exit",()=>app.quit());

function createWindow(){
  const win=new BrowserWindow({
    width:1366,
    height:768,
    minWidth:1024,
    minHeight:650,
    show:false,
    autoHideMenuBar:true,
    backgroundColor:"#38bdf8",
    title:"MATH-a-PANG",
    webPreferences:{
      preload:path.join(__dirname,"preload.js"),
      contextIsolation:true,
      nodeIntegration:false,
      sandbox:false
    }
  });

  mainWindow=win;
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname,"game.html"));
  win.once("ready-to-show",()=>{
    win.show();
    win.maximize();
  });

  win.webContents.setWindowOpenHandler(()=>({action:"deny"}));
  win.webContents.on("will-navigate",(event,url)=>{
    if(!url.startsWith("file:"))event.preventDefault();
  });

  win.on("closed",()=>{
    if(mainWindow===win)mainWindow=null;
  });
}

const gotLock=app.requestSingleInstanceLock();
if(!gotLock){
  app.quit();
}else{
  app.whenReady().then(()=>{
    ensureDataFolder();
    createWindow();
  });
  app.on("window-all-closed",()=>app.quit());
}
