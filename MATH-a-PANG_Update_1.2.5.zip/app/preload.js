const {contextBridge, ipcRenderer} = require("electron");

function snapshotLocalStorage(){
  const data={};
  try{
    for(let i=0;i<localStorage.length;i++){
      const key=localStorage.key(i);
      if(key!==null)data[key]=localStorage.getItem(key);
    }
  }catch(e){}
  return data;
}

try{
  const state=ipcRenderer.sendSync("mathapang:load-state-sync");
  if(state && state.localStorage && typeof state.localStorage==="object"){
    Object.entries(state.localStorage).forEach(([key,value])=>{
      try{localStorage.setItem(key,String(value));}catch(e){}
    });
  }
}catch(e){
  console.error("Could not restore MATH-a-PANG local data:",e);
}

let last="";
function saveIfChanged(){
  try{
    const local=snapshotLocalStorage();
    const now=JSON.stringify(local);
    if(now===last)return;
    last=now;
    ipcRenderer.invoke("mathapang:save-state",{localStorage:local}).catch(()=>{});
  }catch(e){}
}
setInterval(saveIfChanged,700);

window.addEventListener("beforeunload",()=>{
  try{
    ipcRenderer.sendSync("mathapang:save-state-sync",{localStorage:snapshotLocalStorage()});
  }catch(e){}
});

contextBridge.exposeInMainWorld("mathAPangDesktop",{
  openDataFolder:()=>ipcRenderer.invoke("mathapang:open-data-folder"),
  saveNow:()=>ipcRenderer.invoke("mathapang:save-state",{localStorage:snapshotLocalStorage()}),
  exit:()=>ipcRenderer.send("mathapang:exit"),
  isDesktop:true,

  updater:{
    info:()=>ipcRenderer.invoke("mathapang:updater-info"),
    saveConfig:(config)=>ipcRenderer.invoke("mathapang:updater-save-config",config),
    check:()=>ipcRenderer.invoke("mathapang:updater-check"),
    install:()=>ipcRenderer.invoke("mathapang:updater-install"),
    onProgress:(callback)=>{
      if(typeof callback!=="function")return ()=>{};
      const handler=(_event,data)=>callback(data);
      ipcRenderer.on("mathapang:update-progress",handler);
      return ()=>ipcRenderer.removeListener("mathapang:update-progress",handler);
    }
  }
});
